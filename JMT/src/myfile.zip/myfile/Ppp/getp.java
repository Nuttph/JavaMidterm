package myfile.Ppp;

public class getp {
    public static void main(String[]args){
        Ppp p1 = new Ppp();
        p1.a();
//      p1.b();
        p1.c();
    }
}

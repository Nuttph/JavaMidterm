package myfile.Encap;

public class getData {
    public static void main(String[] args){
        Encapsulation e1 = new Encapsulation();
        e1.setNum(20);
        System.out.println(e1.getNum());
    }
}

package myfile.inher;

//Multi Inheritance
public class SpecialDog extends Dog{

}

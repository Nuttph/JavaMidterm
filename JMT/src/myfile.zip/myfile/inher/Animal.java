package myfile.inher;

public class Animal {
    public void testAnimal(){
        System.out.println("Test Animal Success!!");
    }
    public void sound(){
        System.out.println("Animal Sound...");
    }
}